# OBIA Report

LS67 report is developed as an extension which is ready to be deployed in Qlik sense desktop.

Native pivot table is also shared in the given qlik app `OBIA.qvf`

## Prerequisites

1. Qlik sense desktop

## Deployment steps

1. Copy the directory `OBIA_extension` into `C:\Users\[UserName]\Documents\Qlik\Sense\Extensions\`

2. Copy the file `OBIA.qvf` into `C:\Users\[UserName]\Documents\Qlik\Sense\Apps\`

3. Load the data from the CSV file `OBIA_data_modified.csv`

4. Open the existing sheet `OBIA report` to view the extension in action or create a new sheet, drag and drop the extension with name `OBIA_Report` into canvas to view the table rendered by extension.

P.S. Native pivot table is also shared in the sheet `Native report`


