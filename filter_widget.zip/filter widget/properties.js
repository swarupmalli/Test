define([], function () {
    'use strict';
    return {
        type: "items",
        component: "accordion",
        items: {
            mappings: {
                component: "expandable-items",
                label: "Field Mappings",
                items: {
                    currency: {
                        type: "items",
                        label: "Currency",
                        items: {
                            field: {
                                ref: "props.currency",
                                label: "Table field",
                                type: "string",
                                defaultValue: "Currency"
                            }
                        }
                    },
                    units: {
                        type: "items",
                        label: "Values in",
                        items: {
                            field: {
                                ref: "props.units",
                                label: "Table field",
                                type: "string",
                                defaultValue: "Units"
                            }
                        }
                    },
                    view: {
                        type: "items",
                        label: "View",
                        items: {
                            field: {
                                ref: "props.view",
                                label: "Table field",
                                type: "string",
                                defaultValue: "View"
                            }
                        }
                    },
                    entity: {
                        type: "items",
                        label: "Entity",
                        items: {
                            field: {
                                ref: "props.entity",
                                label: "Table field",
                                type: "string",
                                defaultValue: "reporting_entity_cd"
                            }
                        }
                    },
                    date: {
                        type: "items",
                        label: "Date",
                        items: {
                            field: {
                                ref: "props.date",
                                label: "Table field",
                                type: "string",
                                defaultValue: "vCobDate"
                            }
                        }
                    }
                }
            }
        }
    };
} );