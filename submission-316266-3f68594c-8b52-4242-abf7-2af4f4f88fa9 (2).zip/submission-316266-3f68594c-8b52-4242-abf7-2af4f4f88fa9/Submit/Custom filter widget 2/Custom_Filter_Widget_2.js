define( [
    'jquery',
    'qlik',
    './properties',
    './libs/lodash.min',
    'text!./template.ng.html',
    'text!./libs/jquery/jquery-ui.min.css',
    'text!./style.css'
  ],
  function ($, qlik, properties, _, ngTemplate, jqueryUICss, css) {
    'use strict';
    $("<style>").html(css).appendTo("head");
    $("<style>").html(jqueryUICss).appendTo("head");

    Array.prototype.insert = function ( index, item ) {
      this.splice( index, 0, item );
    };

    var app = qlik.currApp(this);
    var backupValue = {};

    /**
     * Get properties from extension ui
     * @param {Object} scope scope of angular
     */
    function getProps(scope) {
      var props = _.get(scope.layout, 'props', {});
      // we set this because the defaultValue doesn't popular first time
      props = _.defaults(props, {
        currency: properties.items.mappings.items.currency.items.field.defaultValue,
        units: properties.items.mappings.items.units.items.field.defaultValue,
        view: properties.items.mappings.items.view.items.field.defaultValue,
        entity: properties.items.mappings.items.entity.items.field.defaultValue,
        date: properties.items.mappings.items.date.items.field.defaultValue,
      });
      return props;
    }

    /**
     * Get options with key from properties
     * 
     * @param {String} key key of properties
     */
    function getOptionsFromProperties(key) {
      var results = app.field(getProps(this)[key]).getData().rows.map(value => value.qText);
      if(!_.isEqual(backupValue[key], results) ) {
        backupValue[key] = results;
      }
      return backupValue[key];
    }

    /**
     * Process selection sections data when change reporting selection field
     */
    function onChangeReportingSelection() {
      var selectionTotal = this.propValue.reportingSelection.id;
      this.propValue.selections.length = selectionTotal;
      _.forEach(this.propValue.selections, (selection, index) => {
        if (!selection) {
          selection = {
            view: 'YTD',
            entity: '',
            date: '',
            varianceWith: {
              id: 0,
            },
          };
          this.propValue.selections[index] = selection;
        }
        selection.varianceWithOptions = [{
          id: 0,
          label: "None",
        }];
        for (var i = 0; i < selectionTotal; i++) {
          if (i !== index) {
            selection.varianceWithOptions.push({
              id: i + 1,
              label: "Selection " + (i + 1),
            });
          }
        }
        if (selection.varianceWith.id > selectionTotal) {
          selection.varianceWith = {
            id: 0,
          };
        }
      });

      setTimeout(function() {
        $( ".custom-filter-widget-2 .datepicker" ).datepicker({ dateFormat: 'dd/mm/yy' });
      }, 0);
    }

    return {
      definition: properties,
      snapshot: {canTakeSnapshot: true},
      template: ngTemplate,
      controller: ['$scope', function ( $scope ) {
        // init value for each options
        $scope.propValue = {
          currency: 'CHF',
          units: 'Millions',
          reportingSelection: {
            id: 1,
          },
          selections: []
        };

        $scope.getOptionsFromProperties = getOptionsFromProperties;
        $scope.reportingSelectionOptions = [
          {
            id: 1,
            label: "One",
          },
          {
            id: 2,
            label: "Two",
          },
          {
            id: 3,
            label: "Three",
          },
          {
            id: 4,
            label: "Four",
          },
          {
            id: 5,
            label: "Five",
          },
        ];
        $scope.onChangeReportingSelection = onChangeReportingSelection;
        $scope.onChangeReportingSelection();

        // date picker
        $scope.showDatePicker = function(query) {
          var element = '.custom-filter-widget-2 ' + query;
          $(element).datepicker("show");
        };
      }]
    };
  } );