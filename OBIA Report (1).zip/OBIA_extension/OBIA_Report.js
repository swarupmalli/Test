define( [
        'jquery',
        'qlik',
        './properties',
		'text!./data.json',
        'text!./template.ng.html',
        'text!./style.css'
    ],
    function ($, qlik, props, data, ngTemplate, css) {
        'use strict';
        $("<style>").html(css).appendTo("head");

        Array.prototype.insert = function ( index, item ) {
            this.splice( index, 0, item );
        };

        var bodyList = [];
        var requests = [];
        var cacheDataMap = {};
        var app = qlik.currApp(this).model.enigmaModel.app;

        /**
         * Sum of multiple array
         * @param {Array} arrays array of array number
         */
        function sumOfMultipleArray(arrays) {
            var calculatedValue;
            for (var arrayNumber of arrays) {
                if (!calculatedValue) {
                    calculatedValue = arrayNumber;
                } else if (arrayNumber) {
                    var length = arrayNumber.length;
                    for (var i = 0; i < length; i++) {
                        calculatedValue[i] += arrayNumber[i];
                    }
                }
            }
            return calculatedValue;
        }

        /**
         * Clone array
         * @param {Array} array array of value
         */
        function cloneArray(array) {
            if (array && array.slice) {
                return array.slice(0);
            }
            return array;
        }

        /**
         * Calculate data for table body
         * @param {Object} input input data
         * @param {Number} level level of data
         */
        function calculateData(input, level) {
            var value = input.value;
            var theLastIndex = bodyList.length;
            var numberValue = null;
            if (!value) {
                numberValue = null;
            } else if (value instanceof Array && value.length > 0) {
                if (!isNaN(value[0])) {
                    // row only contain number
                    var rowValue = [ input.title]
                    numberValue = value;
                } else if (typeof value[0] === 'object') {
                    // row contain object, go deep to child to get sum value
                    var arrayOfListNumber = [];
                    for (var oneValue of value) {
                        arrayOfListNumber.push(calculateData(oneValue, level + 1));
                    }
                    numberValue = sumOfMultipleArray(arrayOfListNumber);
                }
            } else if (typeof value === 'object' && value.sum) {
                var arrayOfListNumber = [];
                for (var fieldId of value.sum) {
                    if (cacheDataMap[fieldId]) {
                        arrayOfListNumber.push(cacheDataMap[fieldId]);
                    }
                }
                numberValue = sumOfMultipleArray(arrayOfListNumber);
            }

            var rowValue = [input.title];
            if (numberValue) {
                var rowValue = [input.title];
                rowValue = rowValue.concat(numberValue);
            } else {
                // row only have title
                rowValue = rowValue.concat(['', '', '', '', '', '','', '', '', '', '', '','', '', '', '', '', '','', '', '', '', '', '','', '', '', '', '', '']);
            }
            var rowUIData = {
                extraClass: input.extraClass ? input.extraClass : '',
                id: input.id ? input.id : '',
                groupLevel: input['group-level'] ? input['group-level'] : '',
                level: numberValue ? level : 'only-title',
                value: rowValue,
                level1Show: true,
                level2Show: true,
            };
            if (input.revertOrder) {
                bodyList.insert(theLastIndex, rowUIData);
            } else {
                bodyList.push(rowUIData);
            }
            if (input.id) {
                cacheDataMap[input.id] = numberValue;
            }
            if (input['ignore-this-value']) {
                return null;
            }
            return cloneArray(numberValue);
        }

        /**
         * Create request for formula
         * @param {Object} input input data
         */
        function createRequests(input) {
            var addRequestToQueue = (container, index, query) => {
                requests.push(app.evaluateEx(query).then( function (engineValue) {
                    container[index] = engineValue.qNumber;
                    return engineValue;
                }));
            };
            var value = input.value
            if (value && value instanceof Array && value.length > 0) {
                if (typeof value[0] === 'string' || value[0] instanceof String) {
                    // row is string formular
                    var index = 0;
                    for(var formula of value) {
                        addRequestToQueue(value, index++, formula);
                    }
                } else if (typeof value[0] === 'object') {
                    for (var oneValue of value) {
                        createRequests(oneValue);
                    }
                }
            }
        }

        /**
         * Format the number
         * @param {Number} number
         */
        var formatNumber = (number) => {
            if (!number || isNaN(number)) {
                return number;
            }
            var formattedNumber = Math.round(Math.abs(number) / 1000).toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            if(number < 0) {
                return '('.concat(formattedNumber, ')');
            }
            return formattedNumber;
        }

        /**
         * Recreate data to render
         * @param {Object} scope angular scope
         * @param {Object} parsedData data to render
         */
        function renderUI(scope, parsedData) {
            bodyList = [];
            for (var value of parsedData.data) {
                calculateData(value, 0);
            }

            var length = bodyList.length - 1;
            for (var i = 0; i < length; i++) {
                if (
                    (bodyList[i].level === 2 && bodyList[i+1].level !== 2) ||
                    (bodyList[i].groupLevel === 3 && bodyList[i+1].groupLevel !== 3)
                ) {
                    bodyList[i].extraClass = bodyList[i].extraClass + ' no-background';
                } 
            }
            scope.data.body = bodyList;
            var notionalTotal =
                bodyList[bodyList.length - 1].value[1] + // section 1
                bodyList[bodyList.length - 1].value[4] +
                bodyList[bodyList.length - 1].value[7] + // section 2
                bodyList[bodyList.length - 1].value[10] +
                bodyList[bodyList.length - 1].value[13] + // section 3
                bodyList[bodyList.length - 1].value[16] +
                bodyList[bodyList.length - 1].value[19] + // section 4
                bodyList[bodyList.length - 1].value[22] +
                bodyList[bodyList.length - 1].value[25] + // section 5
                bodyList[bodyList.length - 1].value[28];
            var prvTotal =
                bodyList[bodyList.length - 1].value[2] + // section 1
                bodyList[bodyList.length - 1].value[5] +
                bodyList[bodyList.length - 1].value[8] + // section 2
                bodyList[bodyList.length - 1].value[11] +
                bodyList[bodyList.length - 1].value[13] + // section 3
                bodyList[bodyList.length - 1].value[17] +
                bodyList[bodyList.length - 1].value[20] + // section 4
                bodyList[bodyList.length - 1].value[23] +
                bodyList[bodyList.length - 1].value[26] + // section 5
                bodyList[bodyList.length - 1].value[29];
            var nrvTotal =
                bodyList[bodyList.length - 1].value[3] + // section 1
                bodyList[bodyList.length - 1].value[6] +
                bodyList[bodyList.length - 1].value[9] + // section 2
                bodyList[bodyList.length - 1].value[12] +
                bodyList[bodyList.length - 1].value[13] + // section 3
                bodyList[bodyList.length - 1].value[18] +
                bodyList[bodyList.length - 1].value[21] + // section 4
                bodyList[bodyList.length - 1].value[24] +
                bodyList[bodyList.length - 1].value[27] + // section 5
                bodyList[bodyList.length - 1].value[30];
            scope.data.footer = [
                'The notional ammount, PRV and NRV (trading and hedging) was CHF ' + formatNumber(notionalTotal) + ' billion, CHF ' + formatNumber(prvTotal) + ' billion and CHF ' + formatNumber(nrvTotal) + ' billion, respectively, as of December 31, 2019',
            ];
        }

        /**
         * Select row at index
         * @param {Object} rowValue row object value
         * @param {number} index row index
         */
        function selectGroup(rowValue, index) {
            if (rowValue.groupLevel && rowValue.groupLevel <= 2) {
                for (var i = index + 1; i < bodyList.length - 1; i++) {
                    if (bodyList[i].groupLevel && rowValue.groupLevel < bodyList[i].groupLevel) {
                        if (rowValue.groupLevel === 2) {
                            bodyList[i].level2Show = !bodyList[i].level2Show;
                        } else if (rowValue.groupLevel === 1) {
                            bodyList[i].level1Show = !bodyList[i].level1Show;
                        }
                    } else {
                        return;
                    }
                }
            }
        }

        return {
            definition: props,
            snapshot: {canTakeSnapshot: true},
            template: ngTemplate,
            controller: ['$scope', function ( $scope ) {
                $scope.formatNumber = formatNumber;
                $scope.selectGroup = selectGroup;
                var parsedData = JSON.parse(data);
                $scope.data = {};
                $scope.data.title = parsedData.title;
				$scope.data.headers = parsedData.headers;
                
                for (var value of parsedData.data) {
                    createRequests(value, 0);
                }

                $.when.apply(undefined, requests).then(function() {
                    // calculate data to directly show on ui after finish all request
                    renderUI($scope, parsedData);
                });
            }]
        };
    } );