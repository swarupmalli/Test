define( [
    'jquery',
    'qlik',
    './properties',
    './libs/lodash.min',
    './libs/moment.min',
    'text!./template.ng.html',
    'text!./style.css',
    'text!./libs/jquery/jquery-ui.min.css',
    'text!./style.css',
  ],
  function ($, qlik, properties, _, moment, ngTemplate, jqueryUICss, css) {
    'use strict';
    $("<style>").html(css).appendTo("head");
    $("<style>").html(jqueryUICss).appendTo("head");
    Array.prototype.insert = function ( index, item ) {
      this.splice( index, 0, item );
    };

    var app = qlik.currApp(this);
    var backupValue = {};

    /**
     * Get properties from extension ui
     * @param {Object} scope scope of angular
     */
    function getProps(scope) {
      var props = _.get(scope.layout, 'props', {});
      // we set this because the defaultValue doesn't popular first time
      props = _.defaults(props, {
        currency: properties.items.mappings.items.currency.items.field.defaultValue,
        units: properties.items.mappings.items.units.items.field.defaultValue,
        view: properties.items.mappings.items.view.items.field.defaultValue,
        entity: properties.items.mappings.items.entity.items.field.defaultValue,
        date: properties.items.mappings.items.date.items.field.defaultValue,
      });
      return props;
    }
    /**
     * Get options with key from properties
     * 
     * @param {String} key key of properties
     */
    function getOptionsFromProperties(key) {
      var results = app.field(getProps(this)[key]).getData().rows.map(value => value.qText);
      if(!_.isEqual(backupValue[key], results) ) {
        backupValue[key] = results;
      }
      return backupValue[key];
    }

    /**
     * Apply options with key from properties
     * 
     * @param {String} key key of properties
     * @param {String} value value of properties
     */
    function applyOptionsFromProperties(key, value) {
      var keyMapping = getProps(this)[key];
      var fieldApi = app.field(keyMapping);
			fieldApi.clear();
      if ((value instanceof moment)) {
				var momentDate = value;
				var searchValue = momentDate.format('DD/MM/YYYY');
				if (searchValue) {
					fieldApi.selectMatch(searchValue, true);
				}
      } else if (value) {
        if (key === 'entity') {
          fieldApi.selectValues([parseInt(value)], false, true);
        } else {
          fieldApi.selectValues([value], false, true);
        }
			}
    }

    return {
      definition: properties,
      snapshot: {canTakeSnapshot: true},
      template: ngTemplate,
      controller: ['$scope', function ( $scope ) {
        // init value for each options
        $scope.propValue = {
          currency: 'CHF',
          units: 'Millions',
          view: 'YTD',
          entity: '',
          date: '',
        };
        $scope.getOptionsFromProperties = getOptionsFromProperties;
        $scope.applyOptionsFromProperties = applyOptionsFromProperties;

        // reselect previous value
        $('.custom-filter-widget-1').find('select.currency,select.units,select.view,select.entity').click(function() {
          if ( $(this).data('clicks') == 1 ) {
            if($(this).hasClass('currency')) {
              $scope.applyOptionsFromProperties('currency', $scope.propValue.currency);
            } else if ($(this).hasClass('units')) {
              $scope.applyOptionsFromProperties('units', $scope.propValue.units);
            } else if ($(this).hasClass('view')) {
              $scope.applyOptionsFromProperties('view', $scope.propValue.view);
            } else if ($(this).hasClass('entity')) {
              $scope.applyOptionsFromProperties('entity', $scope.propValue.entity);
            }
            $(this).data('clicks', 0);
          } else {
              $(this).data('clicks', 1);
          }
      });
      
      $('.custom-filter-widget-1 .currency').focusout( function() {
          $(this).data('clicks', 0);
      });

				// select default value
        $scope.applyOptionsFromProperties('currency', $scope.propValue.currency);
        $scope.applyOptionsFromProperties('units', $scope.propValue.units);
        $scope.applyOptionsFromProperties('view', $scope.propValue.view);
        $scope.applyOptionsFromProperties('entity', $scope.propValue.entity);
        $scope.applyOptionsFromProperties('date', $scope.propValue.date);

        // date picker
        $scope.showDatePicker = function(query) {
          var element = '.custom-filter-widget-1 ' + query;
          $(element).datepicker("show");
        };
        $( ".custom-filter-widget-1 .datepicker" ).datepicker({
          dateFormat: 'dd/mm/yy',
          onSelect: function(date) {
            var momentDate = moment(date, "DD/MM/YYYY");
            if (momentDate && momentDate.isValid()) {
              $scope.applyOptionsFromProperties('date', momentDate);
            }
          },
          onClose: function(date) {
            if (date != "") {
              var momentDate = moment(date, "DD/MM/YYYY");
              if (momentDate && momentDate.isValid()) {
                $scope.applyOptionsFromProperties('date', momentDate);
              }
            }
          }
        });
      }]
    };
  } );