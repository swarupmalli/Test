# LS67 Report

LS67 report is developed as an extension which is ready to be deployed in Qlik sense desktop.

## Prerequisites

1. Qlik sense desktop

## Deployment steps

1. Copy the directory `LS67_extension` into `C:\Users\[UserName]\Documents\Qlik\Sense\Extensions\`

2. Copy the file `LS67.qvf` into `C:\Users\[UserName]\Documents\Qlik\Sense\Apps\`

3. Load the data from the CSV file `LS67_data.csv`

4. Open the existing sheet `LS 67 report` to view the extension in action or create a new sheet, drag and drop the extension with name `LS67_report` into canvas to view the table rendered by extension.
