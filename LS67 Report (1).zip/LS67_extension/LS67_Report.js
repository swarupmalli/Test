/* JS code for LS67 report */
define( [
        'jquery',
        'qlik',
        './properties',
		'text!./data.json',
        'text!./template.ng.html',
        'text!./style.css'
    ],
    function ($, qlik, props, data, ngTemplate, css) {
        'use strict';
        $("<style>").html(css).appendTo("head");

        var tableData = [];
        var requests = [];
        var app = qlik.currApp(this).model.enigmaModel.app;

        // If polyfill is not present, patch the Object.entries function
        if (!Object.entries) {
          Object.entries = function (obj) {
            var ownProps = Object.keys(obj),
                i = ownProps.length,
                resArray = new Array(i);
            while (i--) {
              resArray[i] = [ownProps[i], obj[ownProps[i]]];
             }
            return resArray;
          };
        }

        /**
         * Construct table data for display
         * @param {Object} input Input data
         * @param {Number} level Hierarchy level
         */
        var constructTable = (input, level) => {
            var value = input.value
            if (!value) {
                // row only have title
                tableData.push({
                    level: 'only-title',
                    value: [input.title, '', '', '', '', '', '']
                });
                return null;
            }
            if (value instanceof Array && value.length > 0) {
                if (!isNaN(value[0])) {
                    // row only contain number
                    var rowValue = [input.title];
                    var numberValue = value;
                    numberValue.push(value.reduce((a, b) => {
                        return a + b;
                    }, 0));
                    rowValue = rowValue.concat(numberValue);
                    tableData.push({
                        extraClass: input.extraClass ? input.extraClass : '',
                        level: level,
                        value: rowValue
                    });
                    return numberValue;
                } else if (typeof value[0] === 'object') {
                    // row contain object, go deep to child to get sum value
                    var rowValue = [input.title];
                    var calculatedValue;
                    for (var entry of value) {
                        var resultNumber = constructTable(entry, level + 1);
                        if (!calculatedValue) {
                            calculatedValue = resultNumber;
                        } else if (resultNumber) {
                            var length = resultNumber.length;
                            for (var i = 0; i < length; i++) {
                                calculatedValue[i] += resultNumber[i];
                            }
                        }
                    }
                    rowValue = rowValue.concat(calculatedValue);
                    tableData.push({
                        level: level,
                        value: rowValue
                    });
                    return calculatedValue;
                }
            }
            return null;
        }

        /**
         * Evaluate given formula and generate values
         * @param {Object} input Input data with formula
         */
        var evaluateFormula = (input) => {
            var addRequestToQueue = (container, index, query) => {
                requests.push(app.evaluateEx(query).then( function (engineValue) {
                    if(!isNaN(engineValue.qNumber)) {
                        container[index] = engineValue.qNumber;
                    } else { // If there is error in formula, it will result in NaN
                        container[index] = -1;
                    }         
                }));
            };
            var value = input.value
            if (value && value instanceof Array && value.length > 0) {
                if (typeof value[0] === 'string' || value[0] instanceof String) {
                    // Evaluate formula in each row
                   Object.entries(value).forEach((entry, index) => {
                        addRequestToQueue(value, entry[0], entry[1]); // entry[0] - Index, entry[1] - Formula
                   });
                } else if (typeof value[0] === 'object') {
                    for (var entry of value) {
                        evaluateFormula(entry);
                    }
                }
            }
        }

        /**
         * Format the number
         * @param {Number} number
         */
        var formatNumber = (number) => {
            if (!number || isNaN(number)) {
                return number;
            }
            var formattedNumber = Math.round(Math.abs(number)).toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            if(number < 0) {
                return '('.concat(formattedNumber, ')');
            }
            return formattedNumber;
        }

        /**
         * Recreate data to render
         * @param {Object} scope angular scope
         * @param {Object} parsedData data to render
         */
        var renderUI = (scope, parsedData) => {
            tableData = [];
            for (var value of parsedData.data) {
                constructTable(value, 0);
            }
            tableData.push({
                value: [parsedData["Deferred expenses"].title, '', '', '', '', '', -parsedData["Deferred expenses"].value],
                extraClass: 'deferred-expenses'
            });
            tableData.push({
                value: [parsedData["Allowances for loan losses"].title, '', '', '', '', '', -parsedData["Allowances for loan losses"].value],
            });
            tableData.push({
                value: ['Net loans', '', '', '', '', '', tableData[tableData.length - 5].value[6] - parsedData["Deferred expenses"].value - parsedData["Allowances for loan losses"].value],
                extraClass: 'net-loans'
            });

            var length = tableData.length - 1;
            for (var i = 0; i < length; i++) {
                if (tableData[i].level === 3 && tableData[i+1].level !== 3) {
                    tableData[i].extraClass = 'no-background';
                } 
            }
            scope.data.body = tableData;
        }

        return {
            definition: props,
            snapshot: {canTakeSnapshot: true},
            template: ngTemplate,
            controller: ['$scope', function ( $scope ) {
                $scope.formatNumber = formatNumber;
                var parsedData = JSON.parse(data);
                $scope.data = {};
                $scope.data.title = parsedData.title;
				$scope.data.header = parsedData.header;
                $scope.data.footer = parsedData.footer;
                
				// Evaluate formula in all levels
                for (var formula of parsedData.data) {
                    evaluateFormula(formula, 0);
                }

                $.when(
                    requests,
                    // fetch data for `Allowances for loan losses`
                    app.evaluateEx(parsedData["Allowances for loan losses"].value).then( function (engineValue) {
                        if(!isNaN(engineValue.qNumber)) {
                            parsedData["Allowances for loan losses"].value = Math.abs(engineValue.qNumber);
                        } else { // If there is error in formula, it will result in NaN
                            parsedData["Allowances for loan losses"].value = -1;
                        }   
                    }),
                    // fetch data for `Deferred expenses`
                    app.evaluateEx(parsedData["Deferred expenses"].value).then( function (engineValue) {
                        if(!isNaN(engineValue.qNumber)) {
                            parsedData["Deferred expenses"].value = Math.abs(engineValue.qNumber);
                        } else { // If there is error in formula, it will result in NaN
                            parsedData["Deferred expenses"].value = -1;
                        }
                    })
                ).then(function () {
                    // After evaluation of all formula render UI
                    renderUI($scope, parsedData);
                });
            }]
        };
    } );