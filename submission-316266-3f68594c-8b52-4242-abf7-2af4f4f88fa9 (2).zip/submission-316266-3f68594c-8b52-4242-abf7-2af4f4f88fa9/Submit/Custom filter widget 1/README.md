# Custom_Filter_Widget_1

The instruction for using extension here https://help.qlik.com/en-US/sense-developer/April2019/Subsystems/Extensions/Content/Sense_Extensions/extensions-getting-started.htm#anchor-4 (section Testing the visualization extension)   